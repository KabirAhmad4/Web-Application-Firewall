# SeLabProject
Project title: Task Plus
Owner: Bisma Ali
Developer: Syed Ahsan Imtiaz

Project Description:
	We are developing a software which can manage project and maintain tracking for each member of that project. 
