﻿namespace ClothX.Constants
{
    public enum LookupCategory
    {
        GENDER,
    }
}
