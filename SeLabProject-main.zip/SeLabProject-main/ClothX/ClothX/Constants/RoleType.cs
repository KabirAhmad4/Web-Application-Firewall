﻿namespace ClothX.Constants
{
    public enum RoleType
    {
        Tailor,
        User,
    }
}
