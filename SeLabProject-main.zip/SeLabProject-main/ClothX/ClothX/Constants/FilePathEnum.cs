﻿namespace ClothX.Constants
{
    public enum FilePathEnum
    {
        Uploads,
        Images,
        UserImages,
        ProjectImages,
    }
}
